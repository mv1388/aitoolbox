# AI TOOLBOX #

### Todo ###

* Single stream, multiple topic filter. Split the tweets locally so you can listen effectively to 2 or more streams at the same time.
