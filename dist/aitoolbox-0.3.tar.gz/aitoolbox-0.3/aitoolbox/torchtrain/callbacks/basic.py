import numpy as np

from aitoolbox.torchtrain.callbacks.abstract import AbstractCallback
from aitoolbox.utils import util
from aitoolbox.cloud.AWS.simple_email_service import SESSender


class ListRegisteredCallbacks(AbstractCallback):
    def __init__(self):
        """List all the callbacks which are used in the current TrainLoop

        """
        AbstractCallback.__init__(self, 'Print the list of registered callbacks')

    def on_train_begin(self):
        self.train_loop_obj.callbacks_handler.print_registered_callback_names()


class EarlyStopping(AbstractCallback):
    def __init__(self, monitor='val_loss', min_delta=0., patience=0):
        """Early stopping of the training if the performance stops improving

        Args:
            monitor (str): performance measure that is tracked to decide if performance is improving during training
            min_delta (float): by how much the performance has to improve to still keep training the model
            patience (int): how many epochs the early stopper waits after the performance stopped improving
        """
        # execution_order=99 makes sure that any performance calculation callbacks are executed before and the most
        # recent results can already be found in the train_history
        AbstractCallback.__init__(self, 'EarlyStopping', execution_order=99)
        self.monitor = monitor
        self.min_delta = min_delta
        self.patience = patience

        self.patience_count = self.patience
        self.best_performance = None
        self.best_epoch = 0

    def on_epoch_end(self):
        history_data = self.train_loop_obj.train_history[self.monitor]
        current_performance = history_data[-1]

        if self.best_performance is None:
            self.best_performance = current_performance
            self.best_epoch = self.train_loop_obj.epoch
        else:
            if 'loss' in self.monitor.lower() or 'error' in self.monitor.lower():
                if current_performance < self.best_performance - self.min_delta:
                    self.best_performance = current_performance
                    self.best_epoch = self.train_loop_obj.epoch
                    self.patience_count = self.patience
                else:
                    self.patience_count -= 1
            else:
                if current_performance > self.best_performance + self.min_delta:
                    self.best_performance = current_performance
                    self.best_epoch = self.train_loop_obj.epoch
                    self.patience_count = self.patience
                else:
                    self.patience_count -= 1

            if self.patience_count < 0:
                self.train_loop_obj.early_stop = True
                print(f'Early stopping at epoch: {self.train_loop_obj.epoch}. Best recorded epoch: {self.best_epoch}.')


class TerminateOnNaN(AbstractCallback):
    def __init__(self, monitor='loss'):
        """Terminate training if NaNs are predicted, thus metrics are NaN

        Args:
            monitor (str): performance measure that is tracked to decide if performance is improving during training
        """
        AbstractCallback.__init__(self, 'TerminateOnNaN', execution_order=98)
        self.monitor = monitor

    def on_epoch_end(self):
        last_measure = self.train_loop_obj.train_history[self.monitor][-1]

        if last_measure is not None:
            if np.isnan(last_measure) or np.isinf(last_measure):
                self.train_loop_obj.early_stop = True
                print(f'Terminating on {self.monitor} = {last_measure} at epoch: {self.train_loop_obj.epoch}.')


class AllPredictionsSame(AbstractCallback):
    def __init__(self, value=0., stop_training=False, verbose=True):
        """Checks if all the predicted values are the same

        Useful for example when dealing with extremely unbalanced classes.

        Args:
            value (float): all predictions are the same as this value
            stop_training (bool): if all predictions match the specified value, should the training be (early) stopped
            verbose (bool): output messages
        """
        AbstractCallback.__init__(self, 'All predictions have the same value')
        self.value = value
        self.stop_training = stop_training
        self.verbose = verbose

    def on_epoch_end(self):
        predictions, _, _ = self.train_loop_obj.predict_on_validation_set()

        all_values_same = all(el == self.value for el in predictions)

        if all_values_same:
            if self.verbose:
                print(f'All the predicted values are of the same value: {self.value}')

            if self.stop_training:
                print('Executing early stopping')
                self.train_loop_obj.early_stop = True


class EmailNotification(AbstractCallback):
    def __init__(self, sender_name, sender_email, recipient_email,
                 project_name=None, experiment_name=None, aws_region='eu-west-1'):
        """Notify user via email about the training progression

        Args:
            sender_name (str): Name of the email sender
            sender_email (str): Email of the email sender
            recipient_email (str): Email where the email will be sent
            project_name (str or None): root name of the project
            experiment_name (str or None): name of the particular experiment
            aws_region (str): AWS SES region
        """
        AbstractCallback.__init__(self, 'Send email to notify about the state of training', execution_order=98)
        self.project_name = project_name
        self.experiment_name = experiment_name

        self.ses_sender = SESSender(sender_name, sender_email, recipient_email, aws_region)

    def on_epoch_end(self):
        subject = f"End of epoch {self.train_loop_obj.epoch} report: {self.project_name}: {self.experiment_name}"

        performance_list = self.get_metric_list_html()
        plots_file_paths = self.message_service.read_messages('ModelTrainHistoryPlot_results_file_local_paths')
        plots_file_paths += self.message_service.read_messages('ModelTrainHistoryFileWriter_results_file_local_paths')
        plots_file_paths = util.flatten_list_of_lists(plots_file_paths)

        body_text = f"""<h2>End of epoch {self.train_loop_obj.epoch}</h2>
        {performance_list}
        """

        self.ses_sender.send_email(subject, body_text, plots_file_paths)

    def on_train_end(self):
        subject = f"End of training: {self.project_name}: {self.experiment_name}"

        performance_list = self.get_metric_list_html()
        hyperparams = self.get_hyperparams_html()
        plots_file_paths = self.message_service.read_messages('ModelTrainHistoryPlot_results_file_local_paths')
        plots_file_paths += self.message_service.read_messages('ModelTrainHistoryFileWriter_results_file_local_paths')
        plots_file_paths = util.flatten_list_of_lists(plots_file_paths)

        body_text = f"""<h2>End of training at epoch {self.train_loop_obj.epoch}</h2>
                {performance_list}

                <h3>Used hyper parameters:</h3>
                {hyperparams}
                """

        self.ses_sender.send_email(subject, body_text, plots_file_paths)

    def get_metric_list_html(self):
        """

        Returns:
            str:
        """
        performance_list = '<ul>' + \
                           '\n'.join([f'<li><p>{metric_name}: {hist[-1]}</p></li>'
                                      for metric_name, hist in self.train_loop_obj.train_history.items()]) + \
                           '</ul>'

        return performance_list

    def get_hyperparams_html(self):
        """

        Returns:
            str:
        """
        hyperparams = '<ul>' + \
                      '\n'.join([f'<li><p>{param_name}: {val}</p></li>'
                                 for param_name, val in self.train_loop_obj.hyperparams.items()]) + \
                      '</ul>' \
            if hasattr(self.train_loop_obj, 'hyperparams') else 'Not given'

        return hyperparams

    def on_train_loop_registration(self):
        """

        Tries to infer the project description from the running train loop. If the train loop does not build
        the project folder structure (e.g. basic TrainLoop) the descriptions need to be provided manually to
        this callback.

        Returns:
            None
        """
        try:
            if self.project_name is None:
                self.project_name = self.train_loop_obj.project_name
            if self.experiment_name is None:
                self.experiment_name = self.train_loop_obj.experiment_name
        except AttributeError:
            raise AttributeError('Currently used TrainLoop does not support automatic project folder structure '
                                 'creation. Project name, etc. thus can not be automatically deduced. Please provide'
                                 'it in the callback parameters instead of currently used None values.')


class FunctionOnTrainLoop(AbstractCallback):
    def __init__(self, fn_to_execute,
                 tl_registration=False,
                 epoch_begin=False, epoch_end=False, train_begin=False, train_end=False, batch_begin=False, batch_end=False,
                 after_gradient_update=False, after_optimizer_step=False, execution_order=0):
        """Execute given function as a callback in the TrainLoop

        Args:
            fn_to_execute (function): function logic to be executed at the desired point of the TrainLoop.
                The function should take a single input as an argument which is the reference to the encapsulating
                TrainLoop object (self.train_loop_obj).
            tl_registration (bool): should execute on TrainLoop registration
            epoch_begin (bool): should execute at the beginning of the epoch
            epoch_end (bool): should execute at the end of the epoch
            train_begin (bool): should execute at the beginning of the training
            train_end (bool): should execute at the end of the training
            batch_begin (bool): should execute at the beginning of the batch
            batch_end (bool): should execute at the end of the batch
            after_gradient_update (bool): should execute after the gradient update
            after_optimizer_step (bool): should execute after the optimizer step
            execution_order (int): order of the callback execution. If all the used callbacks have the orders set to 0,
                than the callbacks are executed in the order they were registered.
        """
        AbstractCallback.__init__(self, 'Execute given function as a callback', execution_order)
        self.fn_to_execute = fn_to_execute
        self.tl_registration = tl_registration
        self.epoch_begin = epoch_begin
        self.epoch_end = epoch_end
        self.train_begin = train_begin
        self.train_end = train_end
        self.batch_begin = batch_begin
        self.batch_end = batch_end
        self.after_gradient_update = after_gradient_update
        self.after_optimizer_step = after_optimizer_step

    def execute_callback(self):
        self.fn_to_execute(self.train_loop_obj)

    def on_train_loop_registration(self):
        if self.after_gradient_update or self.after_optimizer_step:
            self.train_loop_obj.grad_cb_used = True

        if self.tl_registration:
            self.execute_callback()

    def on_epoch_begin(self):
        if self.epoch_begin:
            self.execute_callback()

    def on_epoch_end(self):
        if self.epoch_end:
            self.execute_callback()

    def on_train_begin(self):
        if self.train_begin:
            self.execute_callback()

    def on_train_end(self):
        if self.train_end:
            self.execute_callback()

    def on_batch_begin(self):
        if self.batch_begin:
            self.execute_callback()

    def on_batch_end(self):
        if self.batch_end:
            self.execute_callback()

    def on_after_gradient_update(self):
        if self.after_gradient_update:
            self.execute_callback()

    def on_after_optimizer_step(self):
        if self.after_optimizer_step:
            self.execute_callback()
