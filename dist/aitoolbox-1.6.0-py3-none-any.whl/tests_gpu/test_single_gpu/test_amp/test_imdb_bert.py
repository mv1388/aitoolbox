import unittest

import random
import numpy as np
import torch
from torch.utils.data import DataLoader
from torch.optim import AdamW
from torch.cuda.amp import autocast, GradScaler

from transformers import AutoModelForSequenceClassification
from transformers import AutoTokenizer
from datasets import load_dataset

from aitoolbox import TrainLoop, TTModel

"""
Training taken from:
    https://pytorch-ignite.ai/tutorials/beginner/02-transformers-text-classification/
    https://colab.research.google.com/github/pytorch-ignite/pytorch-ignite.ai/blob/gh-pages/tutorials/beginner/02-transformers-text-classification.ipynb
"""


class BERTModel(TTModel):
    def __init__(self, hf_model):
        super().__init__()
        self.hf_model = hf_model

    def forward(self, **kwargs):
        return self.hf_model(**kwargs)

    def get_loss(self, batch_data, criterion, device):
        batch = {k: v.to(device) for k, v in batch_data.items()}
        outputs = self(**batch)
        loss = outputs.loss
        return loss

    def get_predictions(self, batch_data, device):
        batch = {k: v.to(device) for k, v in batch_data.items()}
        outputs = self(**batch)
        logits = outputs.logits
        predictions = torch.argmax(logits, dim=-1)
        return predictions.cpu(), batch["labels"].cpu(), {}


class TestIMDBBERT(unittest.TestCase):
    def test_trainloop_core_pytorch_compare(self):
        train_data, test_data = self.get_data_sets(ds_subset_size=1000)

        val_loss_tl, y_pred_tl, y_true_tl = self.train_eval_trainloop(train_data, test_data, num_epochs=2)
        val_loss_pt, y_pred_pt, y_true_pt = self.train_eval_core_pytorch(train_data, test_data, num_epochs=2)

        self.assertEqual(val_loss_tl, val_loss_pt)
        self.assertEqual(y_pred_tl, y_pred_pt)
        self.assertEqual(y_true_tl, y_true_pt)

    def train_eval_trainloop(self, train_data, test_data, num_epochs):
        self.set_seeds()

        train_loader = DataLoader(train_data, shuffle=True, batch_size=8)
        val_loader = DataLoader(test_data, batch_size=8)

        hf_model = AutoModelForSequenceClassification.from_pretrained("bert-base-cased", num_labels=2)
        model = BERTModel(hf_model)
        optimizer = AdamW(model.parameters(), lr=5e-5)

        print('Start TrainLoop')
        train_loop = TrainLoop(
            model,
            train_loader, val_loader, None,
            optimizer, None,
            use_amp=True
        )
        self.assertEqual(train_loop.device.type, "cuda")

        train_loop.fit(num_epochs=num_epochs)

        val_loss = train_loop.evaluate_loss_on_validation_set(force_prediction=True)
        y_pred, y_true, _ = train_loop.predict_on_validation_set(force_prediction=True)

        return val_loss, y_pred.tolist(), y_true.tolist()

    def train_eval_core_pytorch(self, train_data, test_data, num_epochs):
        self.set_seeds()

        train_loader = DataLoader(train_data, shuffle=True, batch_size=8)
        val_loader = DataLoader(test_data, batch_size=8)

        USE_CUDA = torch.cuda.is_available()
        device = torch.device("cuda" if USE_CUDA else "cpu")
        self.assertEqual(device.type, "cuda")

        model = AutoModelForSequenceClassification.from_pretrained("bert-base-cased", num_labels=2)
        model = model.to(device)
        optimizer = AdamW(model.parameters(), lr=5e-5)

        scaler = GradScaler()

        print('Starting manual PyTorch training')
        model.train()
        for epoch in range(num_epochs):
            print(f'Epoch: {epoch}')
            for i, batch_data in enumerate(train_loader):
                with autocast():
                    batch = {k: v.to(device) for k, v in batch_data.items()}
                    outputs = model(**batch)
                    loss = outputs.loss

                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()

                optimizer.zero_grad()

            # Imitate what happens in auto_execute_end_of_epoch() in TrainLoop
            for _ in train_loader:
                pass
            for _ in val_loader:
                pass

        print('Evaluating')
        val_loss, val_pred, val_true = [], [], []
        model.eval()
        with torch.no_grad():
            for batch_data in val_loader:
                with autocast():
                    batch = {k: v.to(device) for k, v in batch_data.items()}
                    outputs = model(**batch)
                    logits = outputs.logits
                    predictions = torch.argmax(logits, dim=-1)

                    loss_batch = outputs.loss.cpu()

                val_pred += predictions.cpu().tolist()
                val_true += batch["labels"].cpu().tolist()
                val_loss.append(loss_batch)
            val_loss = torch.mean(torch.DoubleTensor(val_loss))

        return val_loss, val_pred, val_true

    def get_data_sets(self, ds_subset_size=0):
        self.set_seeds()

        raw_datasets = load_dataset("imdb")
        tokenizer = AutoTokenizer.from_pretrained("bert-base-cased")

        def tokenize_function(examples):
            return tokenizer(examples["text"], padding="max_length", truncation=True)

        tokenized_datasets = raw_datasets.map(tokenize_function, batched=True)
        tokenized_datasets = tokenized_datasets.remove_columns(["text"])
        tokenized_datasets = tokenized_datasets.rename_column("label", "labels")
        tokenized_datasets.set_format("torch")

        if ds_subset_size == 0:
            train_dataset = tokenized_datasets["train"]
            eval_dataset = tokenized_datasets["test"]
        else:
            train_dataset = tokenized_datasets["train"].shuffle().select(range(ds_subset_size))
            eval_dataset = tokenized_datasets["test"].shuffle().select(range(ds_subset_size))

        return train_dataset, eval_dataset

    @staticmethod
    def set_seeds():
        manual_seed = 0
        torch.backends.cudnn.enabled = False
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True

        np.random.seed(manual_seed)
        random.seed(manual_seed)
        torch.manual_seed(manual_seed)
        # if you are suing GPU
        torch.cuda.manual_seed(manual_seed)
        torch.cuda.manual_seed_all(manual_seed)
